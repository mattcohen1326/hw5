#include "player.h"

Player::Player()
{
    human = false;
    coins = 0;
    stars = 0;
    direction = "right";
    current_col = 0;
    current_row = 19;

}

